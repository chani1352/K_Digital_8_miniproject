package com.pnu.domain;

public enum Role {
	ROLE_ADMIN,ROLE_MEMBER

}
