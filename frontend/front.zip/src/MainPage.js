
export default function MainPage() {
  return (
    <div>
      메인입니다.
    </div>
  )
}
